#include "inputwidget.h"


#include <QtWidgets>


InputWidget::InputWidget(QWidget* parent)
    :QWidget(parent)
{
    ui.setupUi(this);
}
