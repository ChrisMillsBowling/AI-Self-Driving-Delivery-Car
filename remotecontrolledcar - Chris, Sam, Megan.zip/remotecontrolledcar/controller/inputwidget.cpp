#include "inputwidget.h"

InputWidget::InputWidget(QWidget *parent) : QWidget(parent)
{

}
